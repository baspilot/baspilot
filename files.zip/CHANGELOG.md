# Changelog

All notable changes to BASPilot will be documented here.

## [2.0.0] — 2026-05-14

### Added
- Full SaaS platform (landing + auth + dashboard)
- AI transaction categorisation engine (19 rules, 500+ AU merchants)
- GST & BAS calculation engine (G1, 1A, 1B, Label 9)
- File upload system (CSV, XLSX, PDF, PNG/JPG)
- User authentication (login, register, Google sign-in)
- AI Tax Assistant chat
- Premium dashboard with KPI cards and charts
- BAS Due Dates tracker
- Excel white-label report download
- BAS Report generator
- Account settings & white-label branding
- Upgrade modal (Free / Solo $99 / Firm $249)
- Privacy Policy page
- Terms of Service page
- Netlify deployment config with security headers

### Design
- Premium dark SaaS UI (inspired by Stripe, Linear, Vercel)
- Deep blue + cyan glow design system
- Mobile responsive (640px, 900px, 1024px breakpoints)
- Zero CSS variables (100% mobile compatible)
- Inter font

## [1.0.0] — 2026-05-01

### Added
- Initial landing page
- Basic GST calculator
- File upload prototype
