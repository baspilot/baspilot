# BASPilot

> AI-powered BAS preparation platform for Australian accountants and BAS agents.

[![Live](https://img.shields.io/badge/Live-baspilot.com-2563eb?style=flat-square)](https://baspilot.com)
[![Built by](https://img.shields.io/badge/Built%20by-Golden%20Geeks%20Group-10b981?style=flat-square)](https://goldengeeks.com.au)

---

## What is BASPilot?

BASPilot automates BAS (Business Activity Statement) preparation for Australian accounting practices.

**Upload CSV → AI categorises → GST calculated → White-label report ready**

---

## Features

| Feature | Description |
|---|---|
| 🤖 AI Categorisation | 19 rules · 500+ Australian merchants |
| ⚡ GST Automation | Label 1A · 1B · Label 9 · per ATO GSTR 2006/3 |
| 🏷️ White-Label Reports | Your firm branding on every export |
| 🏦 Any Australian Bank | CommBank · ANZ · Westpac · NAB · CSV & Excel |
| 🔒 Privacy-First | All processing in browser · files never uploaded |
| 💬 AI Tax Assistant | GST · BAS · expense guidance (not registered advice) |
| 🔐 Auth System | Login · Register · Google Sign-In |
| 📊 Dashboard | Revenue · Expenses · GST · BAS summary · Due dates |
| 📁 File Upload | Drag & drop · CSV · XLSX · PDF · Progress UI |
| 💳 Stripe Ready | Free · Solo $99 · Firm $249 |

---

## Tech Stack

- **Frontend:** Vanilla HTML · CSS · JavaScript (no framework dependencies)
- **Libraries:** XLSX.js (Excel export)
- **Hosting:** Netlify (recommended)
- **Future:** Supabase (auth) · Stripe (payments) · OpenAI (AI)

---

## Project Structure

```
baspilot/
├── index.html          # Full SaaS app (landing + auth + dashboard)
├── README.md           # This file
├── .gitignore          # Git ignore rules
└── netlify.toml        # Netlify deployment config
```

---

## Deploy to Netlify

### Option 1 — Drag & Drop (60 seconds)
1. Download `index.html`
2. Go to [netlify.com](https://netlify.com)
3. Drag file onto the Netlify dashboard
4. Connect `baspilot.com` domain

### Option 2 — GitHub Auto-Deploy
1. Push to this repository
2. Connect repo in Netlify → "New site from Git"
3. Build command: *(leave empty)*
4. Publish directory: `/`
5. Every `git push` auto-deploys ✅

---

## Environment Variables (Future)

When connecting Supabase + Stripe + OpenAI:

```env
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_ANON_KEY=eyJxx...
STRIPE_PUBLISHABLE_KEY=pk_live_xx...
OPENAI_API_KEY=sk-xx...
```

---

## Legal

- **BASPilot is NOT a registered tax agent** under the Tax Agent Services Act 2009
- Users remain responsible for all BAS lodgements
- Compliant with Australian Privacy Act 1988
- Built in Adelaide, South Australia by Golden Geeks Group

---

## Contact

- **Website:** [baspilot.com](https://baspilot.com)
- **Support:** support@baspilot.com
- **Company:** Golden Geeks Group · Adelaide, SA

© 2026 BASPilot by Golden Geeks Group
